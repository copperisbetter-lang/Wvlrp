G1 Brooke Help: 10 Tripo screenshots showing Jackie head and body from multiple angles. Use as reference for the photo-to-3D workflow for Brooke. Do not overwrite Sophie 1 or Brooke 1.0.
