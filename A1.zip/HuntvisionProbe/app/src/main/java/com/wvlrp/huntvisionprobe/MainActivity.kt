package com.wvlrp.huntvisionprobe

import android.app.Activity
import android.net.wifi.WifiManager
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import java.net.*
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var output: TextView
    private lateinit var progress: ProgressBar
    private val pool = Executors.newFixedThreadPool(32)
    private val commonPorts = intArrayOf(80, 443, 554, 8000, 8080, 8899, 5000)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        output = findViewById(R.id.output); progress = findViewById(R.id.progress)
        findViewById<Button>(R.id.scanButton).setOnClickListener { startScan() }
    }

    private fun log(s: String) = runOnUiThread { output.append(s + "\n") }

    private fun startScan() {
        output.text = ""; progress.visibility = View.VISIBLE
        Thread {
            log("WVLRP Camera Probe v0.1")
            log("Scanning local network only…\n")
            val found = linkedSetOf<String>()
            found.addAll(wsDiscovery())
            val prefix = localPrefix()
            if (prefix != null) {
                log("LAN: ${prefix}0/24")
                val jobs = (1..254).map { n ->
                    pool.submit {
                        val ip = "$prefix$n"
                        if (isAlive(ip)) synchronized(found) { found.add(ip) }
                    }
                }
                jobs.forEach { runCatching { it.get(2200, TimeUnit.MILLISECONDS) } }
            } else log("Could not determine Wi-Fi IPv4 subnet.")

            log("\nDevices worth checking: ${found.size}")
            found.sorted().forEach { inspect(it) }
            log("\nDone. Look for port 554 (RTSP), ONVIF responses, or camera web ports.")
            runOnUiThread { progress.visibility = View.GONE }
        }.start()
    }

    private fun localPrefix(): String? {
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION") val ip = wm.connectionInfo.ipAddress
        if (ip == 0) return null
        return "${ip and 0xff}.${ip shr 8 and 0xff}.${ip shr 16 and 0xff}."
    }

    private fun isAlive(ip: String): Boolean {
        if (runCatching { InetAddress.getByName(ip).isReachable(250) }.getOrDefault(false)) return true
        return commonPorts.any { portOpen(ip, it, 100) }
    }

    private fun portOpen(ip: String, port: Int, timeout: Int = 250): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(ip, port), timeout) }; true
    } catch (_: Exception) { false }

    private fun inspect(ip: String) {
        val ports = commonPorts.filter { portOpen(ip, it) }
        if (ports.isNotEmpty()) log("\n$ip  open=${ports.joinToString(",")}")
        if (554 in ports) log("  RTSP service detected on rtsp://$ip:554/ (path/auth still to identify)")
        for (p in ports.filter { it == 80 || it == 8080 || it == 8000 || it == 8899 }) {
            val banner = httpProbe(ip, p)
            if (banner.isNotBlank()) log("  HTTP:$p  ${banner.take(180).replace("\n", " ")}")
        }
    }

    private fun httpProbe(ip: String, port: Int): String = try {
        Socket().use { s ->
            s.soTimeout = 500; s.connect(InetSocketAddress(ip, port), 300)
            s.getOutputStream().write("HEAD / HTTP/1.0\r\nHost: $ip\r\n\r\n".toByteArray())
            String(s.getInputStream().readBytes().take(512).toByteArray(), StandardCharsets.UTF_8)
        }
    } catch (_: Exception) { "" }

    private fun wsDiscovery(): Set<String> {
        val ips = linkedSetOf<String>()
        val lock = (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).createMulticastLock("wvlrp-onvif").apply { setReferenceCounted(false); acquire() }
        try {
            val id = UUID.randomUUID()
            val xml = """<?xml version="1.0" encoding="UTF-8"?><e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope" xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery" xmlns:dn="http://www.onvif.org/ver10/network/wsdl"><e:Header><w:MessageID>urn:uuid:$id</w:MessageID><w:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To><w:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action></e:Header><e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types></d:Probe></e:Body></e:Envelope>"""
            DatagramSocket().use { sock ->
                sock.soTimeout = 600
                val data = xml.toByteArray(StandardCharsets.UTF_8)
                sock.send(DatagramPacket(data, data.size, InetAddress.getByName("239.255.255.250"), 3702))
                val end = System.currentTimeMillis() + 1800
                while (System.currentTimeMillis() < end) try {
                    val buf = ByteArray(8192); val packet = DatagramPacket(buf, buf.size); sock.receive(packet)
                    val body = String(packet.data, 0, packet.length)
                    ips.add(packet.address.hostAddress ?: continue)
                    log("ONVIF response: ${packet.address.hostAddress}\n  ${body.replace("\n", " ").take(260)}")
                } catch (_: SocketTimeoutException) { break }
            }
        } catch (e: Exception) { log("ONVIF discovery note: ${e.message}") }
        finally { if (lock.isHeld) lock.release() }
        return ips
    }
}
