plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.wvlrp.huntvisionprobe"
    compileSdk = 35
    defaultConfig { applicationId = "com.wvlrp.huntvisionprobe"; minSdk = 26; targetSdk = 35; versionCode = 11; versionName = "11" }
}
