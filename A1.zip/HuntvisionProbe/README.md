# WVLRP Camera Probe v0.1

Android prototype for inspecting cameras you own on the same LAN.

## What it does
- Sends an ONVIF WS-Discovery probe on UDP 3702.
- Scans the phone's local /24 IPv4 network for hosts answering ICMP or common camera TCP ports.
- Checks ports 80, 443, 554, 8000, 8080, 8899, and 5000.
- Flags RTSP on port 554 and collects a small HTTP response banner where available.

## Safety/scope
It does not guess passwords, bypass authentication, exploit devices, or scan the public Internet.

## Build
Open this folder in Android Studio, allow Gradle sync, and build/install the `app` module. Target SDK 35, min SDK 26.

## Next version after first C31W test
Use the observed C31W ports/ONVIF response to add authenticated ONVIF Device/Media calls, GetProfiles/GetStreamUri, snapshot discovery, audio/PTZ capability reporting, and a one-tap WVLRP bridge configuration export.
